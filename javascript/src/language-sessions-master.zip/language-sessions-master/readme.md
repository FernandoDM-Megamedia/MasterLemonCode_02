# Language Sessions

Notas y apuntes para impartir las sesiones de Javascript, Typescript y Programación Funcional del Máster Front-End Lemoncode.